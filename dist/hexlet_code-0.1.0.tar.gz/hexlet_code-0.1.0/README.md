### Hexlet tests and linter status:
## Hexlet tests and linter status:
[![Actions Status](https://github.com/xjem666/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/xjem666/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/2fb8d532f2b79ff8418a/maintainability)](https://codeclimate.com/github/xjem666/python-project-49/maintainability)



## Hexlet Project: Brain Games

Этот проект был создан для обучающей платформы **Hexlet** в рамках программы по изучению профессии **Python-разработчик**. Он содержит пять математических мини-игр:

 - Посчитай-ка! *(Calculations)*
 - Чётное / Нечётное *(Even / Odd)*
 - Вставь пропущенное число *(Fill a Progression)*
 - Найди наибольший общий делитель *(Get a Greatest Common Divisor)*
 - Простое ли это число? *(Prime or Not Prime)*



### Необходимые требования

[Python 3.8.1+](https://www.python.org/downloads/)

[Poetry](https://python-poetry.org/docs/)

### Установка
   

    git clone git@github.com:xjem666/python-project-49.git

>>

    cd python-project-49/
    poetry build
    python -m pip install --user dist/*.whl

### Команды для вызова игр

    brain-even # Чётное / Нечётное
    brain-calc # Вычисления 
    brain-gcd # Нахождение наибольшего общего делителя
    brain-progression # Заполнение прогрессии
    brain-prime # Простое число или нет

### Правила игры
Для **успешного** прохождения любой из игр необходимо дать **три правильных** ответа.

В случае предоставления **неверного** ответа, игра **завершается**.

### Демонастрация возможностей игр

    brain-even 
[![asciicast](https://asciinema.org/a/nlKyPI9lBxzlT2UChqvNXuyrw.svg)](https://asciinema.org/a/nlKyPI9lBxzlT2UChqvNXuyrw)

    brain-calc
[![asciicast](https://asciinema.org/a/l4VOKRygFUh4SsKm83aJycxbG.svg)](https://asciinema.org/a/l4VOKRygFUh4SsKm83aJycxbG)

    brain-gcd
[![asciicast](https://asciinema.org/a/Iq73y3xgUknYWGNQOLKumnjky.svg)](https://asciinema.org/a/Iq73y3xgUknYWGNQOLKumnjky)

    brain-progression
[![asciicast](https://asciinema.org/a/IQH4myuSZIaufH82mKILAegYQ.svg)](https://asciinema.org/a/IQH4myuSZIaufH82mKILAegYQ)

    brain-prime
[![asciicast](https://asciinema.org/a/qRLGzE3YXr0UY7JVHn7zBHqH6.svg)](https://asciinema.org/a/qRLGzE3YXr0UY7JVHn7zBHqH6)
