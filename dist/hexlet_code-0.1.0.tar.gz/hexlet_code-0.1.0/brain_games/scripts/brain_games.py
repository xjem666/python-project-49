def main():
    print("Welcome to the brain games!")
    print('May i have your name? ', end='')
    name = input()
    print("Hello", name)

