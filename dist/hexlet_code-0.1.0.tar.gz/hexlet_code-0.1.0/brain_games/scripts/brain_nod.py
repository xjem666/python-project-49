#!/usr/bin/env python3
from brain_games.games.nod import run_nod


def main():
    run_nod()


if __name__ == "__main__":
    main()