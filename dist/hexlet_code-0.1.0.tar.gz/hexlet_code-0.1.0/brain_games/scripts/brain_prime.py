#!/usr/bin/env python3
from brain_games.games.prime import run_brain_prime


def main():
    run_brain_prime()


if __name__ == "__main__":
    main()
