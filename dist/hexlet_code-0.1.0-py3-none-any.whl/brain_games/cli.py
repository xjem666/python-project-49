import prompt

def make_user():
    name = prompt.string('May I have your name? ')
