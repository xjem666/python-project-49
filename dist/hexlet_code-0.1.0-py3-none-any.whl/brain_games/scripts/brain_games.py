#!/usr/bin/env python3
def main():
    print("Welcome to the Brain Games!")
    print('May I have your name? ', end='')
    name = input()
    print("Hello", name)
