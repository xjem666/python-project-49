AMOUNT_OF_ROUNDS = 3
EVEN_INSTUCTION = 'Answer "yes" if the number is even, otherwise answer "no".'
PROGRESSION_LENGTH = 10