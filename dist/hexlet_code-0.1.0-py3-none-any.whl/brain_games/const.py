AMOUNT_OF_ROUNDS = 3

EVEN_INSTUCTION = 'Answer "yes" if the number is even, otherwise answer "no".'

PROGRESSION_LENGTH = 10

CALC_INSTRUCTION = 'What is the result of the expression?'

NOD_INSTRUCTION = 'Find the greatest common divisor of given numbers.'

PRIME_INSTRUCTION = 'Answer "yes" if the number is prime, otherwise answer "no".'

PROGRESSION_INSTRUCTION = 'What number is missing in the progression?'